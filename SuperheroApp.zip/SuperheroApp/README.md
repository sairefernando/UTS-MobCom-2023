Superheroes app
=================================

Material theming is used to display a list of superheroes in this app. 
The app also demonstrates simple animations.


Pre-requisites
--------------
* Experience with Kotlin syntax.
* How to create and run a project in Android Studio.
* How to create composable functions 
* Familiarity with lazy list


Getting Started
---------------
1. Install Android Studio, if you don't already have it.
2. Download the sample.
3. Import the sample into Android Studio.
4. Build and run the sample.
