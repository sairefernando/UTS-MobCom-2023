package com.example.utsmobcom119_sairefernando.data

import com.example.utsmobcom119_sairefernando.R

object DataProvider {
    val Matkul =
        Matkul(
            id = 1,
            name = "Matematika Diskrit",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g1
        )

    val matkulList = listOf(
        Matkul,
        Matkul(
            id = 2,
            name = "Pengolahan Citra",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g2
        ),
        Matkul(
            id = 3,
            name = "Dasar Dasar Pemrograman",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g3
        ),
        Matkul(
            id = 4,
            name = "Pendidikan Agama Katolik",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g4
        ),
        Matkul(
            id = 5,
            name = "Machine Learning",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g5
        ),
        Matkul(
            id = 6,
            name = "Praktik Kerja Lapangan",
            description = "Menggunakan 6 SKS",
            MatkulImage =  R.drawable.g6
        ),
        Matkul(
            id = 7,
            name = "Pemasaran Digital",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g7
        ),
        Matkul(
            id = 8,
            name = "Animasi Komputer",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g8
        ),
        Matkul(
            id = 9,
            name = "Perancangan Dan Pemrograman Web",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g9
        ),
        Matkul(
            id = 10,
            name = "Mobile Computing",
            description = "Menggunakan 3 SKS",
            MatkulImage = R.drawable.g10
        ),

    )
}
