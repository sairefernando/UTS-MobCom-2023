package com.example.utsmobcom119_sairefernando.data

data class Matkul(
    val id : Int,
    val name: String,
    val description : String,
    val MatkulImage : Int = 0,

)
